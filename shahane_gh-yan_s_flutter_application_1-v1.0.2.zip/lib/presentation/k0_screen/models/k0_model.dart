import 'package:get/get.dart';

class K0Model {}
