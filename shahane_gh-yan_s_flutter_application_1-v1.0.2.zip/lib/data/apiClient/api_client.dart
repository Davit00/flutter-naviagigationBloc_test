import 'package:shahane_gh-yan_s_flutter_application_1/core/app_export.dart';

class ApiClient extends GetConnect {}
