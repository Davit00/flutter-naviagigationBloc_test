final Map<String, String> enUs = {
  'msg_network_err': 'Network Error',
  'msg_something_went_wrong': 'Something Went Wrong!',
  "msg": "Մեքենայի համարանիշ",
  "msg2": "Ներբեռնիր տեխանձնագրի լուսանկարը",
  "lbl6": "Շարունակել",
  "lbl": "Գրանցում",
  "msg_check_your_app":
      "Check your app's UI from the below demo screens of your app.",
  "lbl_app_navigation": "App Navigation",
  "lbl4": "Հեռախոսահամար",
  "lbl5": "Գաղտնաբառ",
  "lbl2": "Անուն ազգանուն",
  "lbl3": "Արմեն Ս"
};
