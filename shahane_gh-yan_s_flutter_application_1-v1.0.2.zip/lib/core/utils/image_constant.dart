import 'package:flutter/material.dart';

class ImageConstant {
  static String img_download1 = 'assets/images/img_download1.svg';

  static String image_not_found = 'assets/images/image_not_found.png';
}
