import 'package:flutter/material.dart';
import 'package:shahane_gh-yan_s_flutter_application_1/core/app_export.dart';

class AppStyle {
  static TextStyle textStyleFreeSans12_1 = textStyleFreeSans12.copyWith(
    color: ColorConstant.bluegray_700,
  );

  static TextStyle textStyleregular20 = TextStyle(
    color: ColorConstant.black_900,
    fontSize: getFontSize(
      20,
    ),
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleFreeSans19 = TextStyle(
    color: ColorConstant.white_A700,
    fontSize: getFontSize(
      19,
    ),
    fontFamily: 'FreeSans',
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleFreeSans16 = textStyleFreeSans12_1.copyWith(
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'FreeSans',
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleregular16 = TextStyle(
    color: ColorConstant.bluegray_400,
    fontSize: getFontSize(
      16,
    ),
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleFreeSans12 = TextStyle(
    color: ColorConstant.bluegray_700_b2,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'FreeSans',
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleFreeSans22 = TextStyle(
    color: ColorConstant.deep_orange_400,
    fontSize: getFontSize(
      22,
    ),
    fontFamily: 'FreeSans',
    fontWeight: FontWeight.w400,
  );
}
